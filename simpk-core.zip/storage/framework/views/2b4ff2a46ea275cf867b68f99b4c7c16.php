


<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(config('app.env') !== 'production'): ?>
    <script src="<?php echo e(asset('js/auto-form-filler.bot.js')); ?>"></script>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php /**PATH C:\Project Web Porto\Sistem Informasi Medis Penyebab Kematian Digital (SIMPK - Digital)\resources\views/partials/watermark.blade.php ENDPATH**/ ?>